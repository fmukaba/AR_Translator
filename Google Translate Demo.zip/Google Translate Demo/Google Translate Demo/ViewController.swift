//
//  ViewController.swift
//  Google Translate Demo
//
//  Created by Evan Johnson on 26/11/19.
//  Copyright © 2019 Evan Johnson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var InputTextField: UITextView!
    @IBOutlet weak var OutputTextField: UITextView!
    
    @IBOutlet weak var InputCodeField: UITextField!
    @IBOutlet weak var OutputCodeField: UITextField!
    
    @IBAction func TranslateBtn(_ sender: Any)
    {
        
        // input the text to be trainslated
        TranslationManager.shared.textToTranslate = self.InputTextField.text
        
        // input the languages to translate to/from
        TranslationManager.shared.sourceLanguageCode = self.InputCodeField.text
        TranslationManager.shared.targetLanguageCode = self.OutputCodeField.text
        
        // send the translation request to GT and update the output field with the result
        TranslationManager.shared.translate(completion: { (translation) in
            
            if let translation = translation {
                
                DispatchQueue.main.async { [unowned self] in
                    self.OutputTextField.text = translation
                }
                
            }
            
        })
        
        
    }
    
    
    
}

